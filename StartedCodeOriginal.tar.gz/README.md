# Compute resources
The training of the models can be done on Datahub, there is a seperate container allocated for you with GPU support and pytorch CUDA integrated.

Container Name: ucsdets/scipy-ml-notebook, (8 CPU, 16G RAM, 1 GPU)

# How to use the autograder

Go to https://www.gradescope.com/ 
   * enroll in CSE 255 (please sign in with your student email and use enrollment code: RZ4BJ5)
   * enroll in DSC 232R (please sign in with your student email and use enrollment code: 57Z4ZG)

Go to HW 5 and submit your files. You will be re-routed to a page where the autograder results will appear, as soon as they finish processing.

## There are three files to submit

results.csv — your predictions on the random test set 

results_country.csv — your predictions on the country test set 

code.zip or code.tgz — your code in a zip file

## Each csv file should have the following columns

filename — e.g. image13724.npz

urban — 1 when urban, 0 when not urban

pred_with_abstention  — predictions of -1, 1, and 0 when I don’t know

pred_wo_abstention - predictions of -1, 1 

## Startup code:
   Github repo: https://github.com/SateeshKumar21/PovertyAnalysis, the repository contains two baselines, CNN and XGboost.
   

## Teams

Teams can consist of 1-4 members. Teams have to be chosen by 29th May and cannot be changed. We will open a dummy gradescope assignment for team selection.
By default, each student is in their own team. The grade of all members of a team is the grade given by the team.

## Grades 

The final scores will be curved and the grade will be scaled according to the formula `score=50+ (percentile/2)` the average of the two scores will be used.

## Evaluation 
The feedback on each submission consists of two average scores - corresponding to the following combinations:
   * Random test / No abstension
   * Country Test / Abstension
   
These will also appear on a class leaderboard. The name under which it appears is your team name.  Please note that the asymmetric loss can be a value between -2 and 1, and appears in the leaderboard that way. In your evaluation test cases, this value is mapped to a number between 0 and 10 so that you don't get negative points.

## Number of submissions per day
Each group can make at most four submissions per 24 hour period. (From midnight to midnight)

